<?php
session_start();
include('header.php');
if(!isset($_SESSION['user']))
{
	
	header('location:login.php');
}
?>
<body class="top-navbar-fixed">
	<div class="main-wrapper">
		<?php include('includes/topbar.php');?>
		<div class="content-wrapper">
			<div class="content-container">
				<?php include('includes/leftbar.php');?>
					<div class="main-page">
						<div class="container-fluid">
							<div class="row page-title-div">
								<div class="col-sm-6">
									<h2 class="title"><i class="fa fa-server">Customer Details</i></h2>
								</div>
							</div>
						</div>
						<div class="section">
							<div class="container-fluid">
								<div class="row">
									<div class="col-md-12">
										<div class="panel">
											<div class="panel-heading">
												<div class="panel-title">
													<h4><i class="fa fa-database"></i>Information</h4>
												</div>
											</div>
											<div class="panel-body">
												<table class="display table table-bordered table-stripped" id="example">
													<thead>
														<tr>
															<th>Customer Name</th>
															<th>Gender</th>
															<th>Email</th>
															<th>Password</th>
															<th>Contacts</th>
															<th>Address</th>
															<th>Action</th>
														</tr>
													</thead>
													<tbody>
<?php
$con=mysqli_connect('127.0.0.1','root','','online');
$qry=mysqli_query($con,"SELECT * FROM customers");
while($row=mysqli_fetch_array($qry))
{
	
?>	
														<tr>
															<td><?php echo $row['name']?></td>
															<td><?php echo $row['gender']?></td>
															<td><?php echo $row['email']?></td>
															<td>****</td>
															<td><?php echo $row['contact']?></td>
															<td><?php echo $row['address']?></td>
															<td>
																<a href="#update<?php echo $row['id']?>" class="btn btn-success btn-xs" data-toggle="modal" data-target="#update<?php echo $row['id']?>">
																	<i class="fa fa-edit"></i>Edit
																</a>
															</td>
														</tr>
														<?php include 'edit_customers.php';?>
<?php }?>												
													</tbody>
												</table>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
			</div>
		</div>
	</div>
<?php
include('table_footer.php');
?>