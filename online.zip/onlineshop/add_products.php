<?php
session_start();
include('header.php');
include('function.php');
if(!isset($_SESSION['user']))
{
	
	header('location:login.php');
}
?>
<?php
$con=mysqli_connect('127.0.0.1','root','','online');
if(isset($_POST['save']))
{
	$product_id=htmlspecialchars($_POST['product_id'],ENT_QUOTES);
	$product_code=htmlspecialchars($_POST['product_code'],ENT_QUOTES);
	$gen_name=htmlspecialchars($_POST['gen_name'],ENT_QUOTES);
	$product_name=htmlspecialchars($_POST['product_name'],ENT_QUOTES);
	$o_price=htmlspecialchars($_POST['o_price'],ENT_QUOTES);
	$price=htmlspecialchars($_POST['price'],ENT_QUOTES);
	$profit=htmlspecialchars($_POST['profit'],ENT_QUOTES);
	$supplier=htmlspecialchars($_POST['supplier'],ENT_QUOTES);
	$qty=htmlspecialchars($_POST['qty'],ENT_QUOTES);
	$qty_sold=htmlspecialchars($_POST['qty_sold'],ENT_QUOTES);
	$expiry=htmlspecialchars($_POST['expiry'],ENT_QUOTES);
	$arrival=htmlspecialchars($_POST['arrival'],ENT_QUOTES);
	
		$qry=mysqli_query($con,"INSERT INTO products(product_id,product_code,gen_name,product_name,o_price,price,profit,supplier,qty,qty_sold,expiry,arrival)
						VALUES('$product_id','$product_code','$gen_name','$product_name','$o_price','$price','$profit','$supplier','$qty','$qty_sold','$expiry','$arrival')");
						
						if($qry){
							echo "<script>alert('Product Added')</script>";
						}
						else{
							echo $con->error;
						}
}
?>
<body class="top-navbar-fixed">
	<div class="main-wrapper">
		<?php include('includes/topbar.php');?>
		<div class="content-wrapper">
			<div class="content-container">
				<?php include('includes/leftbar.php');?>
				<div class="main-page">
					<div class="container-fluid">
						<div class="row page-title-div">
							<div class="col-sm-6">
								<h2 class="title"><i class="fa fa-apple">Add Products</i></h2>
							</div>
						</div>
					</div>
					<div class="section">
						<div class="container-fluid">
							<div class="row">
								<div class="col-md-12">
									<div class="panel">
										<div class="panel-heading">
											<div class="panel-title">
												<h4><i class="fa fa-lemon-o"></i>Products Form</h4>
											</div>
										</div>
										<div class="panel-body">
											<form method="POST" class="form-horizontal">
												<input type="hidden" name="product_id">
												<div class="form-group">
													<label class="col-sm-3 control-label">Product Code</label>
													<div class="col-sm-5">
														<input type="text" name="product_code" class="form-control" required>
													</div>
												</div>
												<div class="form-group">
													<label class="control-label col-sm-3">Product Name</label>
													<div class="col-sm-5">
														<select name="gen_name" class="form-control" required>
															<option>Select</option>
															<option>Select</option>
															<option>Cruciferous</option>
															<option>Allium</option>
															<option>Root</option>
															<option>Marrow</option>														
														</select>
													</div>
												</div>
												<div class="form-group">
													<label class="control-label col-sm-3">Type</label>
													<div class="col-sm-5">
														<select name="product name" class="form-control" required>
<?php
$qry=mysqli_query($con,"SELECT * FROM supplier");
while($row=mysqli_fetch_array($qry))
{
	
?>	
															<option><?php echo $row['product']?></option>
<?php }?>
														</select>
													</div>
												</div>
												<div class="form-group">
													<label class="control-label col-sm-3">Original Price</label>
													<div class="col-sm-5">
														<input type="text" name="o_price" id="txt2" onkeyup="sum();" class="form-control" required>
													</div>
												</div>
												<div class="form-group">
													<label class="control-label col-sm-3">Selling Price</label>
													<div class="col-sm-5">
														<input type="text" name="price" id="txt1" onkeyup="sum();" class="form-control">
													</div>
												</div>
												<div class="form-group">
													<label class="control-label col-sm-3">Profit</label>
													<div class="col-sm-5">
														<input type="text" name="profit" id="txt3" class="form-control" readonly>
													</div>
												</div>
												<div class="form-group">
													<label class="control-label col-sm-3">Supplier</label>
													<div class="col-sm-5">
														<select name="supplier" class="form-control">
															<option>Select</option>
															<?php															
															$qry=mysqli_query($con,"SELECT * FROM supplier");
															while($row=mysqli_fetch_array($qry))
															{
																
															?>
															<option><?php echo $row['name']?></option>
															<?php }?>
														</select>
													</div>
												</div>
												<div class="form-group">
													<label class="control-label col-sm-3">Qty</label>
													<div class="col-sm-5">
														<input type="number" min="0" name="qty" id="txt11" class="form-control" onkeyup="sum();" required>
													</div>
												</div>
												<input type="hidden" name="qty_sold" id="txt22">
												<div class="form-group">
													<label class="control-label col-sm-3">Expiry Date</label>
													<div class="col-sm-5">
														<input type="date" value="<?php echo date('M-d-Y');?>" name="expiry" class="form-control">
													</div>
												</div>
												<div class="form-group">
													<label class="control-label col-sm-3">Arrival Date</label>
													<div class="col-sm-5">
														<input type="date" name="arrival" class="form-control">
													</div>
												</div>
												<div class="form-group">
													<div class="col-sm-offset-2 col-sm-10">
														<button name="save" type="submit" class="btn btn-success">
															<i class="fa fa-save"></i>Add Product
														</button>
													</div>
												</div>
											</form>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
<?php
include('footer.php')
?>