<?php
session_start();
include('header.php');
if(!isset($_SESSION['user']))
{
	
	header('location:login.php');
}
?>
<?php
$con=mysqli_connect('127.0.0.1','root','','online');
if(isset($_POST['save']))
{
	$id=htmlspecialchars($_POST['id'],ENT_QUOTES);
	$name=htmlspecialchars($_POST['name'],ENT_QUOTES);
	$gender=htmlspecialchars($_POST['gender'],ENT_QUOTES);
	$email=htmlspecialchars($_POST['email'],ENT_QUOTES);
	$password=htmlspecialchars($_POST['password'],ENT_QUOTES);
	$contact=htmlspecialchars($_POST['contact'],ENT_QUOTES);
	$address=htmlspecialchars($_POST['address'],ENT_QUOTES);
	
		$qry=mysqli_query($con,"INSERT INTO customers(id,name,gender,email,password,contact,address)
							VALUES('$id','$name','$gender','$email','$password','$contact','$address')");
							
							if($qry)
							{
								echo "<script>alert('Customer Added Successfully')</script>";
							}
							else{
								echo $con->error;
							}
}
?>
<body class="top-navbar-fixed">
	<div class="main-wrapper">
		<?php include('includes/topbar.php');?>
		<div class="content-wrapper">
			<div class="content-container">
				<?php include('includes/leftbar.php');?>
				<div class="main-page">
					<div class="container-fluid">
						<div class="row page-title-div">
							<div class="col-sm-6">
								<h2 class="title"><i class="fa fa-user-plus">Customer Registration</i></h2>
							</div>
						</div>
					</div>
					<div class="section">
						<div class="container-fluid">
							<div class="row">
								<div class="col-md-12">
									<div class="panel">
										<div class="panel-heading">
											<div class="panel-title">
												<h4><i class="fa fa-table"></i>Registration Form</h4>
											</div>
										</div>
										<div class="panel-body">
											<form class="form-horizontal" method="POST">
												<input type="hidden" name="id">
												<div class="form-group">
													<label class="control-label col-sm-3">Customer Name</label>
													<div class="col-sm-5">
														<input type="text" name="name" class="form-control" required>
													</div>
												</div>
												<div class="form-group">
													<label class="control-label col-sm-3">Gender</label>
													<div class="col-sm-5">
														<select name="gender" class="form-control">
															<option>Select</option>
															<option>Male</option>
															<option>Female</option>
														</select>
													</div>
												</div>
												<div class="form-group">
													<label class="control-label col-sm-3">Email</label>
													<div class="col-sm-5">
														<input type="email" name="email" class="form-control" required>
													</div>
												</div>
												<div class="form-group">
													<label class="control-label col-sm-3">Password</label>
													<div class="col-sm-5">
														<input type="password" name="password" class="form-control" required>
													</div>
												</div>
												<div class="form-group">
													<label class="control-label col-sm-3">Contact</label>
													<div class="col-sm-5">
														<input type="text" name="contact" class="form-control">
													</div>
												</div>
												<div class="form-group">
													<label class="control-label col-sm-3">Address</label>
													<div class="col-sm-5">
														<input type="text" name="address" class="form-control">
													</div>
												</div>
												<div class="form-group">
													<div class="col-sm-offset-2 col-sm-10">
														<button type="submit" name="save" class="btn btn-success">
															<i class="fa fa-plus"></i>Add Customer
														</button>
													</div>
												</div>
											</form>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
<?php
include('footer.php');
?>