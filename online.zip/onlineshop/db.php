<?php
$con=mysqli_connect('127.0.0.1','root','','');
$qry=mysqli_query($con,"CREATE DATABASE online");
		if($qry)
		{
			echo "<script>alert('Database Created')</script>";
		}
		else{
			echo $con->error;
		}
?>