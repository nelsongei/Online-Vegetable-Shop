<?php
session_start();
$con=mysqli_connect('127.0.0.1','root','','online');
if(isset($_POST['save']))
{
	
	
	$transaction_id=htmlspecialchars($_POST['transaction_id'],ENT_QUOTES);
	$invoice=htmlspecialchars($_POST['invoice'],ENT_QUOTES);
	$product=htmlspecialchars($_POST['product'],ENT_QUOTES);
	$qty=htmlspecialchars($_POST['qty'],ENT_QUOTES);
	$amount=htmlspecialchars($_POST['amount'],ENT_QUOTES);
	$profit=htmlspecialchars($_POST['profit'],ENT_QUOTES);
	$product_code=htmlspecialchars($_POST['product_code'],ENT_QUOTES);
	$gen_name=htmlspecialchars($_POST['gen_name'],ENT_QUOTES);
	$name=htmlspecialchars($_POST['name'],ENT_QUOTES);
	$price=htmlspecialchars($_POST['price'],ENT_QUOTES);
	$discout=htmlspecialchars($_POST['discout'],ENT_QUOTES);
	$date=htmlspecialchars($_POST['date'],ENT_QUOTES);
}
?>