<div class="modal fade bs-example-modal-md" id="update<?php echo $row['id']?>" tabindex="-1" role="dialog" aria-hidden="true">
	<div class="modal-dialog modal-md">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="close">
					<span aria-hidden="true">X</span>
				</button>
				<h4 class="modal-title" id="myModalLabel2"><i class="fa fa-pencil"></i>Edit Customer</h4>
			</div>
			<div class="modal-body">
				<form method="POST" action="editcustomers.php">
					<input type="hidden" name="id">
					<div class="form-group">
						<label class="">Customer Name</label>
						<div class="">
							<input type="text" name="name"class="form-control" value="<?php echo $row['name']?>" readonly>
						</div>
					</div>
					<div class="form-group">
						<label>Gender</label>
						<div class="">
							<input type="text" name="gender" value="<?php echo $row['gender']?>" class="form-control" readonly>
						</div>
					</div>
					<div class="form-group">
						<label>Email</label>
						<div class="">
							<input type="email" name="email" class="form-control" value="<?php echo $row['email']?>">
						</div>
					</div>
					<div class="form-group">
						<label>Password</label>
						<div class="">
							<input type="password" name="password" class="form-control" value="<?php echo $row['password']?>">
						</div>
					</div>
					<div class="form-group">
						<label>Contact</label>
						<div class="">
							<input type="text" name="contact" class="form-control" value="<?php echo $row['contact']?>" readonly>
						</div>
					</div>
					<div class="form-group">
						<label>Address</label>
						<div class="">
							<input type="text" name="address" class="form-control" value="<?php echo $row['address']?>" readonly>
						</div>
					</div>
					<div class="form-group">
						<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
						<input type="submit" value="Update" class="btn btn-success">
					</div>
				</form>	
			</div>
		</div>
	</div>
</div>