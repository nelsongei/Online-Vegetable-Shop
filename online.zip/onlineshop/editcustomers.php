<?php
$con=mysqli_connect('127.0.0.1','root','','online');
$qry=mysqli_query($con,"UPDATE customers SET email='$_POST[email]',password='$_POST[password]' 
				WHERE id='$_POST[id]'");

			if($qry)
				header("refresh:0; url=customer_info.php");
			else
				echo $con->error;
?> 