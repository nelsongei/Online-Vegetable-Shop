<?php 
include('docs.php');
?>
<div class="left-sidebar bg-success-300 box-shadow ">
    <div class="sidebar-content">
		<div class="user-info closed">
			<i class="fa fa-reddit-alien fa-5x"></i>
			<h6 class="title"><?php echo $_SESSION['user']?></h6>
		</div>
                            <!-- /.user-info -->

        <div class="sidebar-nav">
                                <ul class="side-nav color-gray">
                                    <li class="nav-header">
                                        <span class="">Main Category</span>
                                    </li>
                                    <li>
                                        <a href="dashboard.php"><i class="fa fa-dashboard"></i> <span>Dashboard</span> </a>
                                     
                                    </li>

                                    <li class="nav-header">
                                        <span class="">Appearance</span>
                                    </li>
									<li class="has-children">
                                        <a href="#"><i class="fa fa-users"></i> <span>Customers</span>
											<i class="fa fa-angle-right arrow"></i>
										</a>
                                        <ul class="child-nav">
                                            <li>
												<a href="index.php">
													<i class="fa fa fa-plus"></i>
													<span>Add customer</span>
												</a>
											</li>
											<li>
												<a href="customer_info.php">
													<i class="fa fa-bars"></i>
													<span>Customer Details</span>
												</a>
											</li>
                                        </ul>
                                    </li>
									<li class="has-children">
										<a href="#"><i class="fa fa-leaf"></i><span>Products</span>
											<i class="fa fa-angle-right arrow"></i>
										</a>
										<ul class="child-nav">
											<li>
												<a href="add_products.php">
													<i class="fa fa-lemon-o"></i>
													<span>Add Products</span>
												</a>
											</li>
											<li>
												<a href="manage_products.php">
													<i class="fa fa-table"></i>
													<span>Manage Products</span>
												</a>
											</li>
										</ul>
									</li>
									<li class="has-children">
										<a href="#"><i class="fa fa-user"></i><span>Suppliers</span>
											<i class="fa fa-angle-right arrow"></i>
										</a>
										<ul class="child-nav">
											<li>
												<a href="add_suppliers.php">
													<i class="fa fa-plus-square"></i>
													<span>Add Suppliers</span>
												</a>
											</li>
											<li>
												<a href="manage_supplier.php">
													<i class="fa fa-bars"></i>
													<span>Supplier Information</span>
												</a>
											</li>
										</ul>
									</li>
									<li class="has-children">
										<a href="#"><i class="fa fa-bar-chart"></i><span>Sales</span>
											<i class="fa fa-angle-right arrow"></i>
										</a>
										<ul class="child-nav">
											<li>
												<a href="sales.php?invoice=<?php echo $finalcode?>">
													<i class="fa fa-cart-plus"></i>
													<span>Checkout</span>
												</a>
											</li>
										</ul>
									</li>
                            </div>
                            <!-- /.sidebar-nav -->
    </div>
                        <!-- /.sidebar-content -->
                    </div>