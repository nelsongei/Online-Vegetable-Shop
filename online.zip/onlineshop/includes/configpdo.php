<?php
$dbuser="root";
$dbpass="";
$host="localhost";
$dbname = "aimis";
$mysqli = new mysqli($host, $dbuser, $dbpass, $dbname);

?>